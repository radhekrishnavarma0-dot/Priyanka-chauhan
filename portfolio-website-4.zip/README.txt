PRIYANKA CHAUHAN PORTFOLIO — how to use

1) Open index.html in a browser to preview. It is one self-contained file.

2) Free hosting (HTTPS included):
   - Netlify Drop or Cloudflare Pages: upload this folder. The _headers file adds security headers (CSP etc.). Not yet tested on a live host.
   - GitHub Pages: upload index.html to a repository and enable Pages. GitHub Pages cannot set custom headers, so _headers is ignored there.
   Never put passwords, tokens or API keys in this file or in a public repository.

3) Updating content: open index.html in a text editor and edit the blocks between "EDIT HERE" and "END":
   - CONFIG: email, LinkedIn, GitHub
   - DATA.certs / DATA.projects / DATA.achievements / DATA.education
   - LANGS: change the level (Native, Fluent, Professional, Intermediate, Beginner, Learning)
   - LANGGOALS: add language goals, TECH: Java / Python status
   Images, certificate scans and the CV are embedded in the file; replacing them needs the original files re-encoded.

4) Everything in this file is public, including the CV and certificate scans. A hidden link is not private.
